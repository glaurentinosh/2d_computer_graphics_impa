#ifndef RVG_LUA_PATCH_H
#define RVG_LUA_PATCH_H

int rvg_lua_patch_init(lua_State *L, int ctxidx);
int rvg_lua_patch_export(lua_State *L, int ctxidx);

#endif
