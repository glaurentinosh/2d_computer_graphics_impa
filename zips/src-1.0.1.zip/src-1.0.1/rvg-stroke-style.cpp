#include "rvg-stroke-style.h"

namespace rvg {

const stroke_dashes::const_ptr
    stroke_style::default_dashes_ptr = make_intrusive<stroke_dashes>();

} // namespace rvg
