#ifndef RVG_LUA_RGBA_H
#define RVG_LUA_RGBA_H

#include "rvg-lua.h"

#include "rvg-circle-data.h"

int rvg_lua_rgba_init(lua_State *L, int ctxidx);
int rvg_lua_rgba_export(lua_State *L, int ctxidx);

#endif
