#ifndef RVG_LUA_SCENE_DATA_H
#define RVG_LUA_SCENE_DATA_H

#include "rvg-lua.h"

int rvg_lua_scene_data_init(lua_State *L, int ctxidx);
int rvg_lua_scene_data_export(lua_State *L, int ctxidx);

#endif
