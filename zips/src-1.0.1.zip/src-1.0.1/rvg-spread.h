#ifndef RVG_SPREAD_H
#define RVG_SPREAD_H

namespace rvg {

enum class e_spread {
    clamp,
    wrap,
    mirror,
    transparent
};

} // namespace rvg

#endif
