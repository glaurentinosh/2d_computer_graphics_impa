#ifndef RVG_LUA_FREETYPE_TYPEFACE_H
#define RVG_LUA_FREETYPE_TYPEFACE_H

#include "rvg-lua.h"

int rvg_lua_freetype_typeface_init(lua_State *L, int ctxidx);

#endif
