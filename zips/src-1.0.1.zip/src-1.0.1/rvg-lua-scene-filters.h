#ifndef RVG_LUA_SCENE_FILTERS_H
#define RVG_LUA_SCENE_FILTERS_H

#include "rvg-lua.h"

int rvg_lua_scene_filters_init(lua_State *L, int ctxidx);
int rvg_lua_scene_filters_export(lua_State *L, int ctxidx);

#endif
